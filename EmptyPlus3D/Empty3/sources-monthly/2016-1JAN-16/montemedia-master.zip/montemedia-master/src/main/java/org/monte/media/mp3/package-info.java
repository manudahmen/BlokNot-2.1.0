/* @(#)package-info.java
 *
 * Copyright © 2011 Werner Randelshofer, Goldau, Switzerland.
 * All rights reserved.
 *
 * You may not use, copy or modify this file, except in compliance with the
 * license agreement you entered into with Werner Randelshofer.
 * For details see accompanying license terms.
 *
 * @author Werner Randelshofer
 * @version 1.0 2011-01-03 Created.
*/

/**
 * Provides classes for reading MP3 elementary streams.
 */

package org.monte.media.mp3;
