start-process "cmd.exe" "run.bat"
