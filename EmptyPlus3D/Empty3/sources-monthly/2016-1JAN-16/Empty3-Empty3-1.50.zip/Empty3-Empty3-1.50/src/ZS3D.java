/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface ZS3D {

    public void addToBuffer(Representable r);

    public void removeFromBuffer(Representable r);
}
