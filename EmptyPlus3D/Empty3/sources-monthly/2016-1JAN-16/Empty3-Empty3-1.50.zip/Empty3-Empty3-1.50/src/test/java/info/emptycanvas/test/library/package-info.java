package info.emptycanvas.test.library;

/**
 * *
 * @see ectests project.
 * @version 0.0
 * @author Manuel Dahmen
 */
