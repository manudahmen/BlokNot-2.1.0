package info.emptycanvas.library.renderer;

/***
 * What to do with this system?
 * I'd like to make a new gui for animation creation. Interactive, live.
 * 
 * @author Manuel Dahmen
 */
class TODO
{
}

