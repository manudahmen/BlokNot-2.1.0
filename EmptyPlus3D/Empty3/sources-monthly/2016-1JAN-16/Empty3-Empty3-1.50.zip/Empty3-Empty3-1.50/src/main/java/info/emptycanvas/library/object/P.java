/**
 * *
 * Global license : * CC Attribution
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 **
 */
package info.emptycanvas.library.object;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public class P {

    public static final Point3D n(double a, double b, double c) {
        return new Point3D(a, b, c);
    }
}
