/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

/**
 *
 * @author Manuel DAHMEN
 */
public class Extrusion {

}
