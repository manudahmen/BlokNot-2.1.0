
import java.awt.Color;

import info.emptycanvas.library.object.Representable;

public interface DegradeCouleur {

    public Color color(float[] params01);

    public void dim(int[] params);

    public Representable objet3D();
}
