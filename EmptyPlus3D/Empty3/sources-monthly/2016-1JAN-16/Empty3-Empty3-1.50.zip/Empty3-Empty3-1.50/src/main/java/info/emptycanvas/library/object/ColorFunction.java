/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

import java.awt.Color;

public interface ColorFunction {

    public Color getColorAt(double l, double angle);
}
