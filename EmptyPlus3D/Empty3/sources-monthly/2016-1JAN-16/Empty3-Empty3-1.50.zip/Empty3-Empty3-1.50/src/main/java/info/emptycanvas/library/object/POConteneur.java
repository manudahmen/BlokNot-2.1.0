/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface POConteneur {

    public Iterable<Point3D> iterable();
}
