package info.emptycanvas.library.renderer;

public class TestObjetStub extends TestObjet {

    public void finit() {

    }

    public void ginit() {

    }

    public void testScene() throws Exception {

    }

    public void afterRenderFrame() {
    }

    public void afterRender() {

    }
}
