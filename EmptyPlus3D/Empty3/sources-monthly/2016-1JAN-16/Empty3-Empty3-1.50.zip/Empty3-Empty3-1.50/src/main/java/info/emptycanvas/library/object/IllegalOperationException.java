package info.emptycanvas.library.object;

/**
 *
 * @author Se7en
 */
public class IllegalOperationException extends Exception {

    public IllegalOperationException(String maillage_incorrect) {
    }

}
