/***
Global license : 

    Microsoft Public Licence
    
    author Manuel Dahmen <manuel.dahmen@gmail.com>

***/


package info.emptycanvas.library.object;

/**
 *
 * @author Manuel Dahmen <manuel.dahmen@gmail.com>
 */
public interface DeformMap {
    public Point2D getOtherCordinates(double ValueX, double ValueY);
}
