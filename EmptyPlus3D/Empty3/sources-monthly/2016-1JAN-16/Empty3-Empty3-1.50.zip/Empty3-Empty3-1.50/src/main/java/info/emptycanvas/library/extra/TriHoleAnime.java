/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.extra;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import info.emptycanvas.library.animation.Animation;
import info.emptycanvas.library.object.Point3D;
import info.emptycanvas.library.object.Scene;
import info.emptycanvas.library.object.TRI;
import info.emptycanvas.library.object.TRIObject;

/**
 * @author MANUEL DAHMEN
 *
 * dev
 *
 * 27 déc. 2011
 *
 */
/*
 public class TriHoleAnime extends Animation {
 Polyhedre th ;
 public TriHoleAnime(Scene s) {
 super(s);
 }
	
 private Point3D pcurrent = new Point3D(0,0,0);
 private void modifier(Polyhedre th2) {
 Random r = new Random();
 float fx = (r.nextFloat()-0.5f)*10;
 float fy = (r.nextFloat()-0.5f)*10;
 float fz = (r.nextFloat()-0.5f)*10;
 pcurrent = pcurrent.plus(new Point3D(fx, fy, fz));
 th2.add(pcurrent);
 }

 }
 */
