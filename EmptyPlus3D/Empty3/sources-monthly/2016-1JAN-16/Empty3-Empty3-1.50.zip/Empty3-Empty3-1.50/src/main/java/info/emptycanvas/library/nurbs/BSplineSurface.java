/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 **
 */
package info.emptycanvas.library.nurbs;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public class BSplineSurface {

}
