package info.emptycanvas.library.physics;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import info.emptycanvas.library.object.Matrix33;
import info.emptycanvas.library.object.Point3D;


public class Level1 implements LevelSketch {
}