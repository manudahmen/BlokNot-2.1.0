/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package info.emptycanvas.library.object;

/**
 *
 * @author Se7en
 */
public interface IAnimeTime {

    public double getIncrSec();

    public double getTimeInSeconds();

    public void incr();
}
