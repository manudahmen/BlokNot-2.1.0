/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.script;

public class GrammaireElement {

    public final int NUMBER = 0;
    public final int NAME = 1;
    public final int IDENTIFIER = 2;
    public final int LOOP = 3;
    public final int INSTRUCTION = 4;
    public final int EXPRESSION = 5;
    public final int VARIABLE = 6;

}
