/**
 * *
 * @author Manuel Dahmen
 *
 *
 */
package info.emptycanvas.library;

/**
 * *
 * @author manuel Dahmen
 * @see All classes under info.emptycanvas.library may be working items;
 * be.ibiiztera.**.* are old classes and not up to date.
 * @since 2014
 * @version 2015-S02
 */
