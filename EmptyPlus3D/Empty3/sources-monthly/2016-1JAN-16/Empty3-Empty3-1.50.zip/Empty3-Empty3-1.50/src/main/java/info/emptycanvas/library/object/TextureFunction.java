/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 * Creation time 05-nov.-2014
 *
 **
 */
package info.emptycanvas.library.object;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public interface TextureFunction {
    //public int getColorAt(Point3D);
}
