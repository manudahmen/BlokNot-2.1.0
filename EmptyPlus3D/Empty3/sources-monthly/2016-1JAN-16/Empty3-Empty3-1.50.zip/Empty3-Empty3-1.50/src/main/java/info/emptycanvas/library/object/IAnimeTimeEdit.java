/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package info.emptycanvas.library.object;

/**
 *
 * @author Se7en
 */
public interface IAnimeTimeEdit {

    public void setIncrSec(IAnimeTime T, double dt);

    public void setTimeInSeconds(IAnimeTime T, double t);

}
