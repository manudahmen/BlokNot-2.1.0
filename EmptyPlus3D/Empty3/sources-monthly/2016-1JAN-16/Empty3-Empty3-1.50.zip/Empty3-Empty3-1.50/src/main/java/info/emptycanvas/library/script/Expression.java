/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.script;

public class Expression extends RunElement {

}
