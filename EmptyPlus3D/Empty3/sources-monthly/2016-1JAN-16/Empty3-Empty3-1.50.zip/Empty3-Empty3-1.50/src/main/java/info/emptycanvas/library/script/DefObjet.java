package info.emptycanvas.library.script;

public class DefObjet {

}
