/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface PGenerator {

    public PObjet generatePO();
}
