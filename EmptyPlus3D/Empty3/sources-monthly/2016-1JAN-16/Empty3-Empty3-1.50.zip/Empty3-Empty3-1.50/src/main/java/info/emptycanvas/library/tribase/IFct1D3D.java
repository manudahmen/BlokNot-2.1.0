/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

import info.emptycanvas.library.object.Point3D;

public interface IFct1D3D {

    public int iteres();

    public Point3D value(double t);
}
