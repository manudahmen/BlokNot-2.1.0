package info.emptycanvas.library.physics;

public interface LevelSketch {

}
