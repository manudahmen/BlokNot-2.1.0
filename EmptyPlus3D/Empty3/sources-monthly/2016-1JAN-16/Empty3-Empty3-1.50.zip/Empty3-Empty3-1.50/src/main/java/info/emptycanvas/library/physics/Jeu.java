package info.emptycanvas.library.physics;
import java.net.URL;
import java.util.List;


public class Jeu {
	public String nom;
	public URL carte;
	public int nBillesEnJeu;
	public int nBillesGagnees;
	public int nBillesPerdues;
	
	public List<Bille> billes;
	
	public int points;

	public void updateJoueur(Joueur joueur) {
		
	}
}
