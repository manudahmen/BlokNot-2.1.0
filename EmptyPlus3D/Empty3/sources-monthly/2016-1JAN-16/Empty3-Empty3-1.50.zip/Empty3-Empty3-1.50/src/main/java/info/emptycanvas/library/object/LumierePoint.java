package info.emptycanvas.library.object;

import java.awt.Color;

/**
 *
 * @author Atelier
 */
public interface LumierePoint extends Lumiere {
}
