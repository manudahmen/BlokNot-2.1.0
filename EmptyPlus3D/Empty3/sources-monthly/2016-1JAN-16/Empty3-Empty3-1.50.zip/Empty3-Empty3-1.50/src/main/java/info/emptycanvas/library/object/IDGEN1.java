/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface IDGEN1 {

    public String id();

    public void SET(String gen);
}
