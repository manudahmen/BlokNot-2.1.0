/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <manuel.dahmen@gmail.com>
 *
 **
 */
package info.emptycanvas.library.mesh;

/**
 *
 * @author Manuel Dahmen <manuel.dahmen@gmail.com>
 */
public class Mesh {

}
