/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface TRIGenerable {

    public TRIObject generate();
}
