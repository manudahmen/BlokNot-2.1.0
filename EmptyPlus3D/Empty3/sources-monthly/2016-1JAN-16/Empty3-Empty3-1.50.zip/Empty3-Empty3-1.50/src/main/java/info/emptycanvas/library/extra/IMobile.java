/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.extra;

public interface IMobile {

}
