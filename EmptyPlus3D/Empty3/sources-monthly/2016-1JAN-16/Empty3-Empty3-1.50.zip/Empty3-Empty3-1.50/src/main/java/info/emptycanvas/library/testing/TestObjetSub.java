package info.emptycanvas.library.testing;

public class TestObjetSub extends TestObjet {

    public static void main(String[] args) {

    }

    public void finit() {

    }

    public void ginit() {

    }

    public void testScene() throws Exception {

    }

    public void afterRenderFrame() {
    }

    public void afterRender() {

    }
}
