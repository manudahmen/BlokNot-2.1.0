package info.emptycanvas.library.object;

/**
 *
 * @author Se7en
 */
public class PolyMapPoint3D2DArray
        extends Representable {
}
