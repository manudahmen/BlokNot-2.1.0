/***
Global license : 

    Microsoft Public Licence
    
    author Manuel Dahmen <manuel.dahmen@gmail.com>

***/


package info.emptycanvas.library.tribase.equationeditor;

/**
 *
 * @author Manuel Dahmen <manuel.dahmen@gmail.com>
 */
class EquationLexicalException extends Exception {

    public EquationLexicalException(String not_a_number) {
    }

}
