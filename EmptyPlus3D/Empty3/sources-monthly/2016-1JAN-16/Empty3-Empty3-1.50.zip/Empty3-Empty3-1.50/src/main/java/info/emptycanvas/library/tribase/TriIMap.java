/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

/**
 *
 * @author manuel
 */
public interface TriIMap {

}
