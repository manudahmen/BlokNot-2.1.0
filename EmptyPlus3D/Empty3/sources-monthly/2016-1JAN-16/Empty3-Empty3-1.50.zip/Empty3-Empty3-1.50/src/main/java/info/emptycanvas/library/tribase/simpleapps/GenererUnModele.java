/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <manuel.dahmen@gmail.com>
 *
 **
 */
package info.emptycanvas.library.tribase.simpleapps;

/**
 *
 * @author Manuel Dahmen <manuel.dahmen@gmail.com>
 */
public class GenererUnModele {

}
