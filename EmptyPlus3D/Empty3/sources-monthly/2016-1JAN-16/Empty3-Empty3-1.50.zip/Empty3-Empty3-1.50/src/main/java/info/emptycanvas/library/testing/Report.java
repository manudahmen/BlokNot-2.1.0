/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package info.emptycanvas.library.testing;

/**
 *
 * @author Manuel DAHMEN
 */
public interface Report {

}
