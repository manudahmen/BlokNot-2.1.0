/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.extra;

import info.emptycanvas.library.object.TRIGenerable;
import info.emptycanvas.library.object.TRIObject;
import java.io.File;

/**
 *
 * @author Manuel
 */
public class Puzzle implements TRIGenerable {

    private TRIObject tris;

    public Puzzle(File image) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public TRIObject generate() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
