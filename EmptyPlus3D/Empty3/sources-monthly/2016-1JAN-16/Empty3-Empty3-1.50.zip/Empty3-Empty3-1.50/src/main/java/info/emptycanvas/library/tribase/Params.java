/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

import java.util.HashMap;

public class Params {

    private HashMap<String, Object> params;

    public HashMap<String, Object> getParams() {
        return params;
    }
    // SCREEN PARAMS
    // DISK PARAMS
    // ANIMATION PARAMS
    // 

    public void setParams(HashMap<String, Object> params) {
        this.params = params;
    }
}
