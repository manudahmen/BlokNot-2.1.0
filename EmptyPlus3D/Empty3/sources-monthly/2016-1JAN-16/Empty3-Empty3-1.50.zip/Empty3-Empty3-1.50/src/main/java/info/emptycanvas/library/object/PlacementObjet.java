/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

/**
 *
 * @author manuel
 */
public class PlacementObjet {
}
