/*Should be considered.

Décrire l'âme, de chaque mouvement en détails, le repère mobile de déplacement.

Notamment le déplacement de repère orthonormés 3D a été conçu, "à la va vite",
sans véritable recherche (ne fut-ce que bibliographique, ou de contenu théorique
ou d'exemple concret tirés de la littérature.

Par exemple, dans Empty3, le repères d'un mouvement circulaire:

Le repère mobile (u,v,w) est calculé selon le mouvement. Hors il pourrait, hormis
le déplacement, mais le rotation pourrait être calculé d'après le centre du cercle
et le repère d'axes du centre. (par exemple mouvement des planètes -> ellipse;
progrès car on peut tenir compte de l'eclectique.

*/