/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 **
 */
package stl_loader;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public class IncorrectFormatException extends Exception {

    public IncorrectFormatException() {
    }

}
