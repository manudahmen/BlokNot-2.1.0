/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.script;

public class Value extends RunElement {
	// DOMAIN OBJECT, NUMBER, STRING
}
