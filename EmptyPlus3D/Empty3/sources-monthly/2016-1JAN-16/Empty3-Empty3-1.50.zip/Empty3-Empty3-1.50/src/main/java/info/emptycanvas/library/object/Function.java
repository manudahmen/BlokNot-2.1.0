/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface Function {

    public double getRadius(double l);
}
