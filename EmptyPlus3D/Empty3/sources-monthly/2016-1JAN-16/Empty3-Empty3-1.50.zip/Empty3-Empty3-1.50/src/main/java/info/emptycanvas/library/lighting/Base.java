/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 **
 */
package info.emptycanvas.library.lighting;

import info.emptycanvas.library.object.Point3D;
import info.emptycanvas.library.object.Scene;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public interface Base {

}
