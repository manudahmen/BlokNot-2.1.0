/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

import info.emptycanvas.library.object.Courbe;

import java.util.ArrayList;

/**
 *
 * @author Manuel DAHMEN
 */
public class ApproximationFonction2D implements Courbe {

    private ArrayList<Point> points;

}
