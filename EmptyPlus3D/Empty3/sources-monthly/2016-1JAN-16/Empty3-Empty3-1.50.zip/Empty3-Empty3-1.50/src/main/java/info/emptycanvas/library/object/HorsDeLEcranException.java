package info.emptycanvas.library.object;

/**
 *
 * @author Atelier
 */
public class HorsDeLEcranException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = -1661478980489042845L;

    public HorsDeLEcranException() {
    }

}
