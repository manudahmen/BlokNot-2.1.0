/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.extra;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import info.emptycanvas.library.animation.Animation;
import info.emptycanvas.library.object.Point3D;
import info.emptycanvas.library.object.Scene;
import info.emptycanvas.library.object.TRI;
import info.emptycanvas.library.object.TRIObject;

/**
 * @author MANUEL DAHMEN
 *
 * dev
 *
 * 27 déc. 2011
 *
 */
/*
 public class TriHoleSphereAnime extends Animation {
 Polyhedre th ;
 int n=0;
 public TriHoleSphereAnime(Scene s) {
 super(s);
 }
	
 private Point3D pcurrent = new Point3D(0,0,0);
 private void modifier(Polyhedre th2) {
 th2.deleteAll();
 double a = 0, b=0, R=10;
 n++;
 for(a = 0; a<Math.PI; a+=2.0*Math.PI/n)
 for(b=-Math.PI; b<Math.PI; b+=Math.PI/n)
 {
 pcurrent = new Point3D(R*Math.cos(a)*Math.cos(b),R* Math.cos(a)*Math.sin(b), R*Math.sin(a));
		
 th2.add(pcurrent);
 }
 }

 }
 */
