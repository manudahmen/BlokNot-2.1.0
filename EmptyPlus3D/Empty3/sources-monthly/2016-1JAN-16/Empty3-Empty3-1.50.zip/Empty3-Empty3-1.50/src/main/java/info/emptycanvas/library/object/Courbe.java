/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

/**
 *
 * @author Manuel DAHMEN
 */
public interface Courbe {

}
