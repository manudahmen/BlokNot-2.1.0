package info.emptycanvas.library.object;

/**
 *
 * @author Manuel Dahmen
 */

public class Move {
    
}
