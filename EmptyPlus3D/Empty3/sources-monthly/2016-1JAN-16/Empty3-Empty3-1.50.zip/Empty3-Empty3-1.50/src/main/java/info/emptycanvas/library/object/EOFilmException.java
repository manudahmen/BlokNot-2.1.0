/**
 * *
 * Global license : * CC Attribution
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 **
 */
package info.emptycanvas.library.object;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
class EOFilmException extends Exception {

    public EOFilmException() {
    }

}
