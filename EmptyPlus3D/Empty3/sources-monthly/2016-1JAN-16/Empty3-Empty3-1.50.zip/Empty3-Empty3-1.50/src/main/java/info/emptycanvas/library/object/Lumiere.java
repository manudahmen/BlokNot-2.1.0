package info.emptycanvas.library.object;

import java.awt.Color;

/**
 *
 * @author Atelier
 */
public interface Lumiere {

    public ITexture getCouleur(ITexture base, Point3D p, Point3D n);
}
