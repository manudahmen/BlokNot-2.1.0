package info.emptycanvas.library.testing;

import com.jogamp.opengl.swt.GLCanvas;
import javax.swing.JFrame;

/**
 *
 * @author Se7en
 */
public class OpenGLWindow extends JFrame{
    private GLCanvas canvas;
    public OpenGLWindow(String title)
    {
        super(title);
    }
}
