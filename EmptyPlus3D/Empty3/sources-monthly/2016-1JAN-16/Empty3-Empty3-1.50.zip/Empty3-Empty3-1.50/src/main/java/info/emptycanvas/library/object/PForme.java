package info.emptycanvas.library.object;

/*

 Vous êtes libre de :

 */
