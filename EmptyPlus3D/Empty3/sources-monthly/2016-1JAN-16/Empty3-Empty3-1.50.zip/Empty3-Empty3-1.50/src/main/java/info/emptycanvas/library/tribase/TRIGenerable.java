/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

import info.emptycanvas.library.object.TRIObject;

public interface TRIGenerable {

    public TRIObject generate();
}
