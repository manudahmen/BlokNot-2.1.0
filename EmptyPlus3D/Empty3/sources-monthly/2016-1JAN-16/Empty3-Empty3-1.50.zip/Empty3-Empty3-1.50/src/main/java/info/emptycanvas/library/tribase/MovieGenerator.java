/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.tribase;

import java.awt.Component;

public class MovieGenerator extends BaseGenerator {

    public MovieGenerator(int dx, int dy, Component c) {
        super(dx, dy, c);
    }

}
