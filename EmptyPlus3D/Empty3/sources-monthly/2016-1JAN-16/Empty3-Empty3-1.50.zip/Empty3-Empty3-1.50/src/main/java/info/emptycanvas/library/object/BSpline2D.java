/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

@Deprecated
public class BSpline2D extends Representable {

}
