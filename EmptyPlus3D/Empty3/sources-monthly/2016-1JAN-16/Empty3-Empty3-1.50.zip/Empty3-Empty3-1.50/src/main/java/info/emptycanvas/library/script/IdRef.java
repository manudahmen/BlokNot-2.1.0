package info.emptycanvas.library.script;

public class IdRef {

    public IdRef() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @param args
     */
}
