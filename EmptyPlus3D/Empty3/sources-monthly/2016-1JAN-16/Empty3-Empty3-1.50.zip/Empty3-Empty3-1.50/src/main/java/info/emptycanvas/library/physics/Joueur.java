package info.emptycanvas.library.physics;
import java.awt.Color;
import java.net.URL;

import javax.swing.BoundedRangeModel;


public class Joueur {
	public Joueur(String text, Color color2) {
		this.nom = text;
		this.color = color2;
	}
	public String nom;
	public Color color;
	public URL avatar;
	public URL email;
	public String password;
	public int billes;
	
	}
