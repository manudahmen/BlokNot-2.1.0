package info.emptycanvas.library.object;

public class LumiereElement {

    public Point3D point;
    public Point3D normale;

}
