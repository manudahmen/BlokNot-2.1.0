/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

public interface TRIConteneur {

    public Representable getObj();

    public Iterable<TRI> iterable();
}
