/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <manuel.dahmen@gmail.com>
 *
 **
 */
package info.emptycanvas.library.tribase.simpleapps;

import javax.swing.JFrame;

/**
 *
 * @author Manuel Dahmen <manuel.dahmen@gmail.com>
 */
public class VisualiserObjet 
{
    
    public VisualiserObjet()
    {
        VisualiserObjetJF v = new VisualiserObjetJF();
    }
    
    public static void main(String [] args)
    {
        JFrame appFrame;
        appFrame = new JFrame("");
    }
            
}
