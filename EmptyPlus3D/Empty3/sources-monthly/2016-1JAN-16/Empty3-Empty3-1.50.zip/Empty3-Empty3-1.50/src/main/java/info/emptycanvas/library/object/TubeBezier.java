/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.object;

/**
 * @author MANUEL DAHMEN
 *
 * dev
 *
 * 10 oct. 2011
 *
 */
public class TubeBezier extends Representable {

    private Barycentre position;

    @Override
    public void position(Barycentre p) {
        this.position = p;
    }

}
