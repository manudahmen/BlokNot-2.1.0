/***
Global license : 

    Microsoft Public Licence
    
    author Manuel Dahmen <manuel.dahmen@gmail.com>

***/


package info.emptycanvas.library.tribase;

import info.emptycanvas.library.nurbs.ParametrizedCurve;

/**
 *
 * @author Manuel Dahmen <manuel.dahmen@gmail.com>
 */
public abstract class DPath extends ParametrizedCurve{

}
