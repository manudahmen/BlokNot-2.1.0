/*

 Vous êtes libre de :

 */
package info.emptycanvas.library.script;

public abstract class InterpreteConstants {

    public abstract void registerConstants(String name, int value, Interprete interprete);

}
