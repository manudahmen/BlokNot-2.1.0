/**
 * *
 * Global license : * Microsoft Public Licence
 *
 * author Manuel Dahmen <ibiiztera.it@gmail.com>
 *
 **
 */
package info.emptycanvas.library.lighting;

import info.emptycanvas.library.object.Representable;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public class Infini extends Representable {

    public static final Representable Default = new Infini();

}
